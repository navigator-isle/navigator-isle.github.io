# Passage Planner – Google Play release kit

> Planning aid only – not for navigation.
> Model: **free download · full app free for 60 days · then ₱200 one-time lifetime unlock** (Google Play in-app product `pro_lifetime`).

## What's in this folder
| File / folder | Purpose |
|---|---|
| `index.html` | The whole app (trial, unlock screen and Google Play billing built in) |
| `capacitor/` + `.github/workflows/build-apk.yml` | Builds the **Android app with the app packed inside** (works offline) on GitHub's servers → signed `.aab` for Google Play |
| `scripts/make-upload-key.sh` | Creates your upload (signing) key |
| `privacy.html` | Privacy policy (public link required by Google) |
| `store/` | Play graphics + `store-listing.md` (all texts and form answers) |
| `manifest.webmanifest`, `sw.js`, `icons/` | Website / PWA version |

**Why the Capacitor build (not PWABuilder):** with a paid unlock the app must be inside the APK. A PWABuilder app loads the website, which anyone could open free in a browser. The website version shows the same trial; after 60 days it points people to the Play app.

---

## Step 1 · Google Play developer account (1–3 days)
1. play.google.com/console → **Personal** account → US$25 → identity verification (ID, address) → verify phone and Android device (Play Console app).
2. **Setup → Payments profile**: name, address, **bank account**, tax info (TIN). Needed before you can sell anything.

## Step 2 · Signing key (once, on a computer with Java – Windows: Git Bash)
1. Run `scripts/make-upload-key.sh` → it creates `upload.keystore` and prints 4 values.
2. **Back up `upload.keystore` and the password** (Google Drive + e-mail to yourself).
3. GitHub → repository → **Settings → Secrets and variables → Actions → New repository secret** → add the 4 secrets it printed (`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`).

No computer? Tell Claude – the workflow can be changed to create the key on GitHub and give it to you as a download once.

## Step 3 · Build the app on GitHub (≈10 min)
1. Upload this whole folder to your repository (incl. hidden `.github`). Your website keeps working – `index.html` is the same app.
2. **Actions → Build Android app → Run workflow**.
3. When it's green: open the run → **Artifacts → passage-planner-android** → `PassagePlanner-release.aab` (for Play) and `PassagePlanner-release.apk` (to try on your phone).
4. New version later: raise `"version"` in `capacitor/package.json` (e.g. 1.0.1), run again – the version code goes up automatically.

## Step 4 · Create the app in Play Console
**Create app** → name `Passage Planner – Ship Routes` · English · App · **Free** → create.

## Step 5 · First upload (needed before the ₱200 product can exist)
**Test and release → Testing → Closed testing → Create track** → **Create release** → upload `PassagePlanner-release.aab` → accept **Play App Signing** → release name `1.0.0` → save (you can roll it out in Step 9).

## Step 6 · Create the ₱200 lifetime product
1. **Monetize with Play → Products → In-app products → Create product**
2. Product ID: **`pro_lifetime`** (exactly – the app looks for this name)
3. Name: `Full version (lifetime)` · Description: `Unlock every feature for life – one-time payment, no subscription.`
4. Price: **₱200.00** (PHP) → let Google convert other countries → **Save → Activate**.

## Step 7 · Test the purchase for free
1. **Setup → License testing** → add your Gmail (and testers') → license response `RESPOND_NORMALLY`.
2. Install the app from the closed-test link → ☰ → **Unlock full version** → buy with the test card (no charge) → app unlocks.
3. Uninstall → reinstall → ☰ → About → **Restore purchase** → unlocked again.
4. To see the trial end: there is no shortcut in the release app; trust the website test or ask Claude for a test build.

## Step 8 · Store listing and App content
Copy everything from `store/store-listing.md`: descriptions (they state the 60-day trial and ₱200 clearly – required by Google), graphics, category Maps & Navigation, privacy URL `https://navigator-isle.github.io/privacy.html`, content rating, target audience 18+, data safety.

## Step 9 · Closed test → production
1. Roll out the closed-test release; add **≥ 12 testers** (Gmail list) and send them the opt-in link; keep it running **14 days**.
2. **Dashboard → Apply for production** → answer the questions → after approval **Production → Create release** with the same `.aab` → roll out. Review 1–7 days.

## Money
Google keeps **15 %** → about **₱170** per sale, paid monthly to your bank once over the payout threshold.

## Updating
Change → run the workflow → upload the new `.aab` (Production → Create release). The website: replace `index.html`.

## Your details
- Website: https://navigator-isle.github.io/ · Privacy policy: https://navigator-isle.github.io/privacy.html
- Package name: `app.passageplanner.navigation` · In-app product: `pro_lifetime`
