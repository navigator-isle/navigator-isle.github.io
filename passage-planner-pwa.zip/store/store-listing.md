# Google Play listing – ready to paste

## Main store listing
**App name** (max 30 characters)
`Passage Planner – Ship Routes`  (29)

**Short description** (max 80)
`Passage planning, waypoint actions, ETA & weather · 60 days free, then ₱200 once`  (80)

**Full description** (max 4000)
```
Passage Planner is a planning aid for deck officers and masters. Plan a berth-to-berth passage on your phone, tablet or laptop – even offline at sea.

PASSAGE PLANNING
• Route between 3,700+ world ports (UN/LOCODE search) through straits, canals and traffic separation schemes
• Great circle, rhumb line and composite sailing – set Start GC / End GC on any waypoint
• Import and check RTZ routes from your ECDIS; export RTZ and CSV
• ECA / DECA zones, VTS areas, MARPOL special areas, PSSAs, speed-restriction zones and high-risk areas on the chart, with entry and exit waypoints
• Berth-to-berth summary with ECA legs for the fuel change-over plan
• NAVAREAs and NAVTEX stations along the route, ENC usage bands and cells per waypoint, nautical publications

WAYPOINT ACTION POINTS
• Bridge actions at every waypoint and on every leg with regulation references (SOLAS, COLREG, MARPOL, STCW, ISPS)
• Pilot outbound / inbound, COSP / EOSP, position-fixing intervals, ECDIS safety settings, UKC, 12 nm and 50 nm points, echo sounder, ECA notices, VTS reports, NAVAREA and Inmarsat-C ocean-region changes, ship's clocks and date line
• Parallel-index lines with reference, distance and side for coastal legs
• Your own notes per waypoint

WEATHER
• Forecast along the route for the ship's ETA at each point (wind, gusts, waves, swell, current, visibility, pressure)
• 3-day forecast at your GPS position or any position

CALCULATORS
• ETA – single passage or multi-port voyage with port stays, required arrival time and speed; zone times filled in automatically with daylight saving time
• Squat at different speeds, safety depth / UKC and ECDIS safety contour
• Sunrise, sunset and twilight
• Sailing calculators with diagrams: great circle (vertex and waypoints), Mercator, parallel sailing, dead reckoning, estimated position, composite sailing
• Voyage draft plan with fuel, diesel and fresh-water tanks and a hydrostatic table

FREE FOR 60 DAYS – THEN ₱200 ONCE, FOR LIFE
• Download free – no payment details needed
• Every feature works for 60 days from first use
• Then a one-time ₱200 in-app purchase keeps everything unlocked for life – no subscription, no ads
• After the trial, saved plans stay viewable even without unlocking
• Purchase linked to your Google account – Restore purchase on a new phone

PRIVATE BY DESIGN
No account, no ads, no tracking. Plans are saved inside the app on your device; back them up to one file to move them to another phone.

IMPORTANT
Passage Planner is a planning aid only and is NOT for navigation. Zones, limits, depths, weather and positions are approximate. Always verify against official ENC / paper charts, Sailing Directions, ALRS, Notices to Mariners and your company SMS.
```

## Graphics (in this folder)
| Asset | File | Play requirement |
|---|---|---|
| App icon | `play-icon-512.png` | 512 × 512 PNG |
| Feature graphic | `feature-graphic.png` | 1024 × 500 |
| Phone screenshots | `phone-1 … phone-6` | 1080 × 1920 (2–8 required) |
| 7-inch tablet | `tablet7-*.png` | 1920 × 1200 |
| 10-inch tablet | `tablet10-*.png` | 1920 × 1200 |

Tip: the chart background in these screenshots is plain because they were made offline. For a nicer listing, retake phone screenshots on your phone with the chart loaded. Use 9:16 portrait and no status-bar clutter.

## Store settings
- **Category:** Maps & Navigation
- **Tags:** Navigation, Maps, Productivity
- **Contact e-mail:** mjgaly.mg@gmail.com (required, shown publicly)
- **Price:** Free app · **contains in-app purchases** (Play shows this automatically once the product exists)
- **Privacy policy URL:** `https://navigator-isle.github.io/privacy.html`

## App content (Policy → App content)
| Item | Answer |
|---|---|
| Privacy policy | URL above |
| Ads | No, the app contains no ads |
| In-app purchases | Yes – one-time product `pro_lifetime`, ₱200 |
| App access | All functionality is available without special access (no login) |
| Content rating (IARC questionnaire) | Category "Reference, News or Educational" or "Utility"; answer **No** to all violence, sexual, drugs, gambling and user-interaction questions → expected rating: Everyone / PEGI 3 |
| Target audience | 18 and over (professional seafarers). Not designed for children |
| News app | No |
| Health / financial / government app | No |
| Data safety | see below |

## Data safety form
- **Does your app collect or share any of the required user data types?** → **Yes** (only one type, see below)
  - **Location → Precise location:** collected = Yes · shared = No · **processed ephemerally = Yes** · **optional** (user can choose) · purpose = **App functionality**.
    Reason: when the user taps GPS under *Weather at a position*, the position is sent to Open-Meteo to fetch that forecast. It is not stored and not sent to the developer. Showing the GPS position on the chart and sun times are calculated on the device (not "collected").
  - All other data types (personal info, files, app activity, device IDs …) → **not collected**. Plans, notes and settings never leave the device.
- **Is all user data encrypted in transit?** → Yes (HTTPS only)
- **Do you provide a way for users to request that their data is deleted?** → Data stays on the device: delete saved plans in the app, clear app data or uninstall.
- Account creation: none.
- **Purchase history:** purchases are processed by Google Play; the app itself sends no purchase data anywhere (it only keeps an "unlocked" flag on the phone). Mark *Financial info → Purchase history* as **not collected** unless the Console's own guidance for Play Billing tells you otherwise.

## Permissions to declare
- `ACCESS_FINE_LOCATION` / `ACCESS_COARSE_LOCATION`: foreground only, to show the ship's position and calculate sun times. No background location, so no extra Play declaration is needed.
- `INTERNET`
